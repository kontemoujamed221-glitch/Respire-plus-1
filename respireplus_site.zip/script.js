document.querySelector('.cod-form').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('Merci pour votre commande ! Nous vous contacterons bientôt pour confirmer la livraison.');
});